#include <gtk/gtk.h>
typedef struct
{
int jour;
char temps[30];

float valeur;

}dechet;

void afficher_meilleure_menu(GtkWidget * liste);
void meilleur_menu_de_la_semaine_nutrition();

